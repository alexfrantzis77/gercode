OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(int(plasticity_index(55, 25))) == '34173cb38f07f89ddbebc2ac9128303f'\n"
                                               ">>> assert get_hash(int(plasticity_index(60, 40))) == '98f13708210194c475687be6106a3b84'\n"
                                               ">>> assert get_hash(int(plasticity_index(30, 5))) == '8e296a067a37563370ded05f5a3bf3ec'\n",
                                       'failure_message': 'Your funtion is misclassifying the plasticity index of some samples!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
