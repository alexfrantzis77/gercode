OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(plasticity(10).upper()) == 'd20caec3b48a1eef164cb4ca81ba2587'\n"
                                               ">>> assert get_hash(plasticity(30).upper()) == 'd20caec3b48a1eef164cb4ca81ba2587'\n"
                                               ">>> assert get_hash(plasticity(45).upper()) == 'd20caec3b48a1eef164cb4ca81ba2587'\n"
                                               ">>> assert get_hash(plasticity(49.9).upper()) == 'd20caec3b48a1eef164cb4ca81ba2587'\n",
                                       'failure_message': 'Your funtion is misclassifying some low plasticity samples!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all low plasticity test cases :D'},
                                   {   'code': ">>> assert get_hash(plasticity(55).upper()) == 'c1d9f50f86825a1a2302ec2449c17196'\n"
                                               ">>> assert get_hash(plasticity(60).upper()) == 'c1d9f50f86825a1a2302ec2449c17196'\n"
                                               ">>> assert get_hash(plasticity(70).upper()) == 'c1d9f50f86825a1a2302ec2449c17196'\n"
                                               ">>> assert get_hash(plasticity(50.1).upper()) == 'c1d9f50f86825a1a2302ec2449c17196'\n",
                                       'failure_message': 'Your funtion is misclassifying some high plasticity samples!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all high plasticity test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
