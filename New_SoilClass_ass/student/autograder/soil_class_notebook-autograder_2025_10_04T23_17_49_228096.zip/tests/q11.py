OK_FORMAT = True

test = {   'name': 'q11',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q11)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(classify_soil(10, 55, 0, 0, 0, 55, 25).upper()) == '1ee0bf89c5d1032317d13a2e022793c8'\n"
                                               ">>> assert get_hash(classify_soil(10, 60, 0, 0, 0, 75, 25).upper()) == '1ee0bf89c5d1032317d13a2e022793c8'\n"
                                               ">>> assert get_hash(classify_soil(10, 75, 0, 0, 0, 30, 20).upper()) == '5bc574a47246f122016869b32a6aa6f0'\n"
                                               ">>> assert get_hash(classify_soil(10, 60, 0, 0, 0, 60, 30.7).upper()) == '1ee0bf89c5d1032317d13a2e022793c8'\n"
                                               ">>> assert get_hash(classify_soil(10, 75, 0, 0, 0, 55, 45).upper()) == '002f27e5064e874ecf4f5def17d1b797'\n"
                                               ">>> assert get_hash(classify_soil(10, 80, 0, 0, 0, 75, 45).upper()) == '002f27e5064e874ecf4f5def17d1b797'\n"
                                               ">>> assert get_hash(classify_soil(10, 62, 0, 0, 0, 30, 25).upper()) == 'd01fd9b01e9dde8bd3dc247afbfb7218'\n"
                                               ">>> assert get_hash(classify_soil(10, 75, 0, 0, 0, 60, 30.9).upper()) == '002f27e5064e874ecf4f5def17d1b797'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(classify_soil(10, 75, 0, 0, 0, 20, 10).upper()) == '5bc574a47246f122016869b32a6aa6f0'\n"
                                               ">>> assert get_hash(classify_soil(10, 67, 0, 0, 0, 10, 7).upper()) == 'd01fd9b01e9dde8bd3dc247afbfb7218'\n"
                                               ">>> assert get_hash(classify_soil(10, 59, 0, 0, 0, 20, 17).upper()) == 'd01fd9b01e9dde8bd3dc247afbfb7218'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert classify_soil(40, 4, 0.3, 0.14, 0.025, 0, 0).upper() == 'GW'\n"
                                               ">>> assert classify_soil(40, 4, 0.15, 0.13, 0.1, 0, 0).upper() == 'GP'\n"
                                               ">>> assert classify_soil(40, 10, 0.3, 0.14, 0.025, 30, 25).upper() == 'GW-GM'\n"
                                               ">>> assert classify_soil(40, 10, 0.3, 0.14, 0.025, 30, 15).upper() == 'GW-GC'\n"
                                               ">>> assert classify_soil(40, 10, 0.15, 0.13, 0.1, 30, 25).upper() == 'GP-GM'\n"
                                               ">>> assert classify_soil(40, 10, 0.15, 0.13, 0.1, 30, 15).upper() == 'GP-GC'\n"
                                               ">>> assert classify_soil(40, 20, 0.15, 0.13, 0.1, 30, 25).upper() == 'GM'\n"
                                               ">>> assert classify_soil(40, 20, 0.15, 0.13, 0.1, 30, 15).upper() == 'GC'\n"
                                               ">>> assert classify_soil(40, 20, 0.15, 0.13, 0.1, 25, 20).upper() == 'GC-GM'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(classify_soil(50, 1, 2, 1.1, 0.3, 0, 0).upper()) == 'c17d19f7520be36addbeb5d2c76ab7cf'\n"
                                               ">>> assert get_hash(classify_soil(50, 1, 2, 1.5, 0.3, 0, 0).upper()) == 'ad2d8ee7d788dcf41f399818f639cb64'\n"
                                               ">>> assert get_hash(classify_soil(50, 6, 0.45, 0.25, 0.1, 60, 40).upper()) == 'c31f61bf166e30ec55828503fad107d4'\n"
                                               ">>> assert get_hash(classify_soil(50, 6, 0.45, 0.25, 0.1, 60, 30).upper()) == 'acb50b1138e657e40d297035097d0bf1'\n"
                                               ">>> assert get_hash(classify_soil(50, 6, 0.45, 0.2, 0.1, 60, 40).upper()) == '03f9d3f62bd6324143e47935f642177a'\n"
                                               ">>> assert get_hash(classify_soil(50, 6, 0.45, 0.2, 0.1, 60, 30).upper()) == 'f9bb4d123b6b669ac79bd9465d619d00'\n"
                                               ">>> assert get_hash(classify_soil(50, 13, 0.15, 0.13, 0.1, 20, 17).upper()) == '64f3bd1741ab8d6ba545a1ae09bb8728'\n"
                                               ">>> assert get_hash(classify_soil(50, 13, 0.15, 0.13, 0.1, 55, 25).upper()) == '7359c3eb5c57547295a76ac1bf775b29'\n"
                                               ">>> assert get_hash(classify_soil(50, 13, 0.15, 0.13, 0.1, 10, 4).upper()) == '58a3dd33c44967a9f632495eaf1b41b0'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert classify_soil(60, 4, 0.3, 0.14, 0.025, 0, 0).upper() == 'SW'\n"
                                               ">>> assert classify_soil(60, 4, 0.15, 0.13, 0.1, 0, 0).upper() == 'SP'\n"
                                               ">>> assert classify_soil(60, 10, 0.3, 0.14, 0.025, 30, 25).upper() == 'SW-SM'\n"
                                               ">>> assert classify_soil(60, 10, 0.3, 0.14, 0.025, 30, 15).upper() == 'SW-SC'\n"
                                               ">>> assert classify_soil(60, 10, 0.15, 0.13, 0.1, 30, 25).upper() == 'SP-SM'\n"
                                               ">>> assert classify_soil(60, 10, 0.15, 0.13, 0.1, 30, 15).upper() == 'SP-SC'\n"
                                               ">>> assert classify_soil(65, 20, 0.15, 0.13, 0.1, 30, 25).upper() == 'SM'\n"
                                               ">>> assert classify_soil(65, 20, 0.15, 0.13, 0.1, 30, 15).upper() == 'SC'\n"
                                               ">>> assert classify_soil(65, 20, 0.15, 0.13, 0.1, 25, 20).upper() == 'SC-SM'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(classify_soil(60, 1, 2, 1.1, 0.3, 0, 0).upper()) == '6f56aa4e2561eb66f17f6d8de8070a77'\n"
                                               ">>> assert get_hash(classify_soil(60, 1, 2, 1.5, 0.3, 0, 0).upper()) == '674769e3326f8cf937af4282f2815c02'\n"
                                               ">>> assert get_hash(classify_soil(60, 6, 0.7, 0.3, 0.1, 60, 40).upper()) == '65c56b049b73002cf51b3af4e2bd53fe'\n"
                                               ">>> assert get_hash(classify_soil(60, 6, 0.7, 0.3, 0.1, 60, 30).upper()) == 'f419abeb5493c8c55303eb149514d422'\n"
                                               ">>> assert get_hash(classify_soil(60, 6, 0.45, 0.25, 0.1, 60, 40).upper()) == '1f6c58153add4babee7e71c6901c7134'\n"
                                               ">>> assert get_hash(classify_soil(60, 6, 0.45, 0.2, 0.1, 60, 30).upper()) == 'b04d57f315980016bd43ba0ef4a25a3e'\n"
                                               ">>> assert get_hash(classify_soil(70, 13, 0.15, 0.13, 0.1, 20, 17).upper()) == '4e0d4f6ce30646f5a3f3e2a7422c1c5a'\n"
                                               ">>> assert get_hash(classify_soil(70, 13, 0.15, 0.13, 0.1, 55, 25).upper()) == '6a65edb0cc17d66c677814115b1477f5'\n"
                                               ">>> assert get_hash(classify_soil(70, 13, 0.15, 0.13, 0.1, 10, 4).upper()) == 'ed68e6ebff520017f868f48f2dc722c5'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
