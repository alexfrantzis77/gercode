OK_FORMAT = True

test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q4)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(silt_or_clay(55, 25).upper()) == '0d61f8370cad1d412f80b84d143e1257'\n"
                                               ">>> assert get_hash(silt_or_clay(75, 25).upper()) == '0d61f8370cad1d412f80b84d143e1257'\n"
                                               ">>> assert get_hash(silt_or_clay(30, 20).upper()) == '0d61f8370cad1d412f80b84d143e1257'\n"
                                               ">>> assert get_hash(silt_or_clay(60, 30.7).upper()) == '0d61f8370cad1d412f80b84d143e1257'\n",
                                       'failure_message': 'Your funtion is misclassifying some low plasticity samples!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all low plasticity test cases :D'},
                                   {   'code': ">>> assert get_hash(silt_or_clay(55, 45).upper()) == '69691c7bdcc3ce6d5d8a1361f22d04ac'\n"
                                               ">>> assert get_hash(silt_or_clay(75, 45).upper()) == '69691c7bdcc3ce6d5d8a1361f22d04ac'\n"
                                               ">>> assert get_hash(silt_or_clay(30, 25).upper()) == '69691c7bdcc3ce6d5d8a1361f22d04ac'\n"
                                               ">>> assert get_hash(silt_or_clay(60, 30.9).upper()) == '69691c7bdcc3ce6d5d8a1361f22d04ac'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {'code': ">>> assert get_hash(silt_or_clay(20, 10).upper()) == '0d61f8370cad1d412f80b84d143e1257'\n", 'hidden': False, 'locked': False, 'points': 0},
                                   {   'code': ">>> assert get_hash(silt_or_clay(10, 7).upper()) == '69691c7bdcc3ce6d5d8a1361f22d04ac'\n"
                                               ">>> assert get_hash(silt_or_clay(20, 17).upper()) == '69691c7bdcc3ce6d5d8a1361f22d04ac'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
