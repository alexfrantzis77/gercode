OK_FORMAT = True

test = {   'name': 'optimization',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(int(maxShearAngle(30, 30, 40))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(maxShearAngle(100, 0, 0))) == '7f1de29e6da19d22b51c68001e7e0e54'\n"
                                               ">>> assert get_hash(int(maxShearAngle(0, 100, 0))) == 'f7177163c833dff4b38fc8d2872f1ec6'\n"
                                               ">>> assert get_hash(int(maxShearAngle(200, 10, 100))) == '06409663226af2f3114485aa4e0a23b4'\n"
                                               ">>> assert get_hash(int(maxShearAngle(50, 50, -25))) == '8613985ec49eb8f757ae6439e879bb2a'\n"
                                               ">>> assert get_hash(int(maxShearAngle(80, -20, 20))) == '2b24d495052a8ce66358eb576b8912c8'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
