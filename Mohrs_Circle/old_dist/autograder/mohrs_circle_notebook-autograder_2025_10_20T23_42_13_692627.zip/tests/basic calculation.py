OK_FORMAT = True

test = {   'name': 'basic calculation',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q0)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> assert np.isclose(calcStress(55, 25, 20, 0), [55, 25, 20], rtol=0.01, atol=0.01).all() == True\n'
                                               '>>> assert np.isclose(calcStress(55, 25, 20, 90), [25, 55, -20], rtol=0.01, atol=0.01).all() == True\n'
                                               '>>> assert np.isclose(calcStress(200, 10, 100, 30), [239.1025, -29.1025, -32.2724], rtol=0.1, atol=0.1).all() == True\n'
                                               ">>> assert get_hash(int(calcStress(80, 0, 10, 45)[0])) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n"
                                               ">>> assert get_hash(int(calcStress(80, 0, 10, 45)[1])) == '34173cb38f07f89ddbebc2ac9128303f'\n"
                                               ">>> assert get_hash(int(calcStress(80, 0, 10, 45)[2])) == '046be5694dce5d772d74b8f6964149a2'\n"
                                               ">>> assert get_hash(int(calcStress(0, 0, 50, 45)[0])) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n"
                                               ">>> assert get_hash(int(calcStress(0, 0, 50, 45)[1])) == '25d3122a93ce9214a42700a394acb5f4'\n"
                                               ">>> assert get_hash(int(calcStress(0, 0, 50, 45)[2])) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(calcStress(55, 25, 20, 180)[0])) == 'a684eceee76fc522773286a895bc8436'\n"
                                               ">>> assert get_hash(int(calcStress(55, 25, 20, 180)[1])) == '8e296a067a37563370ded05f5a3bf3ec'\n"
                                               ">>> assert get_hash(int(calcStress(55, 25, 20, 180)[2])) == '98f13708210194c475687be6106a3b84'\n"
                                               ">>> assert get_hash(int(calcStress(30, 30, 40, 60)[0])) == 'ea5d2f1c4608232e07d3aa3d998e5135'\n"
                                               ">>> assert get_hash(int(calcStress(30, 30, 40, 60)[1])) == '0267aaf632e87a63288a08331f22c7c3'\n"
                                               ">>> assert get_hash(int(calcStress(30, 30, 40, 60)[2])) == 'b9ea889c6fc3fb2b4c343d7400734856'\n"
                                               ">>> assert get_hash(int(calcStress(0, 100, 0, 30)[0])) == '1ff1de774005f8da13f42943881c655f'\n"
                                               ">>> assert get_hash(int(calcStress(0, 100, 0, 30)[1])) == 'd09bf41544a3365a46c9077ebb5e35c3'\n"
                                               ">>> assert get_hash(int(calcStress(0, 100, 0, 30)[2])) == '17e62166fc8586dfa4d1bc0e1742c08b'\n"
                                               ">>> assert get_hash(int(calcStress(0, 100, 0, 60)[0])) == 'ad61ab143223efbc24c7d2583be69251'\n"
                                               ">>> assert get_hash(int(calcStress(0, 100, 0, 60)[1])) == '8e296a067a37563370ded05f5a3bf3ec'\n"
                                               ">>> assert get_hash(int(calcStress(0, 100, 0, 60)[2])) == '17e62166fc8586dfa4d1bc0e1742c08b'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all test cases :D'},
                                   {   'code': ">>> assert get_hash(int(np.sum(calcStress(1500, 200, 100, np.linspace(0, 180, 360))))) == '26fbf9269a02a4fb6786a651f600cf2e'\n"
                                               ">>> assert get_hash(int(np.mean(calcStress(1500, 200, 100, np.linspace(0, 180, 360))))) == 'db85e2590b6109813dafa101ceb2faeb'\n"
                                               ">>> assert get_hash(int(calcStress(1500, 200, 100, np.linspace(0, 180, 3))[0][0])) == 'cfa5301358b9fcbe7aa45b1ceea088c6'\n"
                                               ">>> assert get_hash(int(calcStress(1500, 200, 100, np.linspace(0, 180, 3))[0][1])) == '3644a684f98ea8fe223c713b77189a77'\n"
                                               ">>> assert get_hash(int(calcStress(1500, 200, 100, np.linspace(0, 180, 3))[0][2])) == 'cfa5301358b9fcbe7aa45b1ceea088c6'\n"
                                               ">>> assert get_hash(int(calcStress(1500, 200, 100, np.linspace(0, 180, 3))[1][0])) == '3644a684f98ea8fe223c713b77189a77'\n"
                                               ">>> assert get_hash(int(calcStress(1500, 200, 100, np.linspace(0, 180, 3))[1][1])) == 'cfa5301358b9fcbe7aa45b1ceea088c6'\n"
                                               ">>> assert get_hash(int(calcStress(1500, 200, 100, np.linspace(0, 180, 3))[1][2])) == '3644a684f98ea8fe223c713b77189a77'\n"
                                               ">>> assert get_hash(int(calcStress(1500, 200, 100, np.linspace(0, 180, 3))[2][2])) == 'f899139df5e1059396431415e770c6dd'\n",
                                       'failure_message': 'Your funtion is not behaving well on array inputs!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
