OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert type(fig_1).__name__ == 'Figure'\n",
                                       'failure_message': 'Make sure to create a figure and assign it to fig_1.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_xdata()), decimals=2)) == '47f6d46a79d004de38c6d3c1174ca637'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_ydata()), decimals=2)) == '62dca49f0781bf26b4305bddb0414bea'\n",
                                       'failure_message': 'Check x and y data of plot.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> x_string = ['NORMAL', 'STRESS', 'MPA']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_xlabel().upper() for word in x_string]), 'Check the x-axis label.'\n"
                                               ">>> y_string = ['SHEAR', 'STRESS', 'MPA']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_ylabel().upper() for word in y_string]), 'Check the y-axis label.'\n",
                                       'failure_message': 'Check figure labels',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> title_string = ['CIRCLE', 'DIAGRAM']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_title().upper() for word in title_string]), 'Check the title label.'\n",
                                       'failure_message': 'Check title.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert fig_1.axes[0].get_xlim() == (0, 1600), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_1.axes[0].get_ylim() == (-800, 800), 'Check the y-axis limits.'\n",
                                       'failure_message': 'Check axis limits.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
