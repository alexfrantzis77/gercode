OK_FORMAT = True

test = {   'name': 'q3',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> fig_1 = makeFigure()\n>>> assert type(fig_1).__name__ == 'Figure'\n<Figure size 800x800 with 1 Axes>",
                                       'failure_message': 'Make sure to create a figure and assign it to fig_1.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> fig_1 = makeFigure()\n'
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_xdata()), decimals=2)) == '47f6d46a79d004de38c6d3c1174ca637'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_ydata()), decimals=2)) == '62dca49f0781bf26b4305bddb0414bea'\n"
                                               '<Figure size 800x800 with 1 Axes>',
                                       'failure_message': 'Check x and y data of plot.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> fig_1 = makeFigure()\n'
                                               ">>> x_string = ['NORMAL', 'STRESS', 'MPA']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_xlabel().upper() for word in x_string]), 'Check the x-axis label.'\n"
                                               ">>> y_string = ['SHEAR', 'STRESS', 'MPA']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_ylabel().upper() for word in y_string]), 'Check the y-axis label.'\n"
                                               '<Figure size 800x800 with 1 Axes>',
                                       'failure_message': 'Check figure labels',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> fig_1 = makeFigure()\n'
                                               ">>> title_string = ['CIRCLE', 'DIAGRAM']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_title().upper() for word in title_string]), 'Check the title label.'\n"
                                               '<Figure size 800x800 with 1 Axes>',
                                       'failure_message': 'Check title.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> fig_1 = makeFigure()\n'
                                               ">>> assert fig_1.axes[0].get_xlim() == (0, 1600), 'Check the x-axis limits.'\n"
                                               ">>> assert fig_1.axes[0].get_ylim() == (-800, 800), 'Check the y-axis limits.'\n"
                                               '<Figure size 800x800 with 1 Axes>',
                                       'failure_message': 'Check axis limits.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
