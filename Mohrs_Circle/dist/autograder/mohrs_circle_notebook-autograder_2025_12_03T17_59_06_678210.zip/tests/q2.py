OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(int(maxShearAngle(30, 30, 40)[1])) == 'd67d8ab4f4c10bf22aa353e27879133c'\n"
                                               ">>> assert get_hash(int(maxShearAngle(100, 0, 0)[1])) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n"
                                               ">>> assert get_hash(int(maxShearAngle(0, 100, 0)[1])) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n"
                                               ">>> assert get_hash(int(maxShearAngle(200, 10, 100)[1])) == '3988c7f88ebcb58c6ce932b957b6f332'\n"
                                               ">>> assert get_hash(int(maxShearAngle(50, 50, -25)[1])) == '8e296a067a37563370ded05f5a3bf3ec'\n"
                                               ">>> assert get_hash(int(maxShearAngle(80, -20, 20)[1])) == 'd82c8d1619ad8176d665453cfb2e55f0'\n",
                                       'failure_message': 'Your funtion is incorrectly calculating the max shear stress',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly calculates max shear stress :D'},
                                   {   'code': ">>> assert get_hash(int(maxShearAngle(30, 30, 40)[0])) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(maxShearAngle(100, 0, 0)[0])) == '7f1de29e6da19d22b51c68001e7e0e54'\n"
                                               ">>> assert get_hash(int(maxShearAngle(0, 100, 0)[0])) == 'f7177163c833dff4b38fc8d2872f1ec6'\n"
                                               ">>> assert get_hash(int(maxShearAngle(200, 10, 100)[0])) == '06409663226af2f3114485aa4e0a23b4'\n"
                                               ">>> assert get_hash(int(maxShearAngle(50, 50, -25)[0])) == '8613985ec49eb8f757ae6439e879bb2a'\n"
                                               ">>> assert get_hash(int(maxShearAngle(80, -20, 20)[0])) == '2b24d495052a8ce66358eb576b8912c8'\n",
                                       'failure_message': 'Your funtion is incorrectly calculating the optimum angle!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly calculates optimum angle :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
