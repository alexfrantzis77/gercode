OK_FORMAT = True

test = {   'name': 'q3',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> """ # BEGIN TEST CONFIG\n'
                                               '>>> name: Starting Calcs\n'
                                               '>>> points: 0\n'
                                               '>>> failure_message: Your funtion clusterSoils is getting some calculations wrong!\n'
                                               '>>> success_message: Function passes all test cases :D\n'
                                               '>>> """\n'
                                               '>>> _cw, _labs = clusterSoils(features_whitened, k=3, seed=0)\n'
                                               ">>> assert _cw.shape == (3, len(feature_cols)), f'clusterSoils: centroid shape should be (3, {len(feature_cols)}), got {_cw.shape}'\n"
                                               ">>> assert len(_labs) == features_whitened.shape[0], f'clusterSoils: labels length should be {features_whitened.shape[0]}, got {len(_labs)}'\n"
                                               ">>> assert set(_labs) == {0, 1, 2}, f'clusterSoils: expected labels {{0,1,2}}, got {set(_labs)}'\n"
                                               ">>> print('clusterSoils ✓  shape and label checks passed')\n"
                                               'clusterSoils ✓  shape and label checks passed\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
