OK_FORMAT = True

test = {   'name': 'q4',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> """ # BEGIN TEST CONFIG\n'
                                               '>>> name: Starting Calcs\n'
                                               '>>> points: 0\n'
                                               '>>> failure_message: Your funtion clusterSoils is getting some calculations wrong!\n'
                                               '>>> success_message: Function passes all test cases :D\n'
                                               '>>> """\n'
                                               ">>> _valid_groups = {'Sandy', 'Silty', 'Clayey'}\n"
                                               ">>> assert isinstance(q5, dict), 'q5 should be a dictionary'\n"
                                               ">>> assert set(q5.keys()) == {0, 1, 2}, f'q5 should have keys {{0, 1, 2}}, got {set(q5.keys())}'\n"
                                               ">>> assert set(q5.values()) == _valid_groups, f'q5 values must be {_valid_groups}, got {set(q5.values())}. Check spelling.'\n"
                                               ">>> print('q5 ✓  format and label checks passed')\n"
                                               'q5 ✓  format and label checks passed\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
