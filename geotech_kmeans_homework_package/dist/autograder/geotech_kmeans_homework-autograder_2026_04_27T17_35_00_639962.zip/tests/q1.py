OK_FORMAT = True

test = {   'name': 'q1',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(example_id)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> _w_test = [8, 10, 12, 14, 16, 18]\n'
                                               '>>> _gd_test = [16.5, 17.8, 18.6, 18.9, 18.4, 17.6]\n'
                                               '>>> q1 = fitProctorCurve(_w_test, _gd_test, degree=2)\n'
                                               ">>> assert get_hash(round(float(q1(9)), 1)) == '1b7f864ac7a422c1a24c720d543e7e0f', 'fitProctorCurve: unexpected value at w=9'\n"
                                               ">>> assert get_hash(round(float(q1(10)), 1)) == '1383c2b19889c144c1c67203d8f7d201', 'fitProctorCurve: unexpected value at w=10'\n"
                                               ">>> assert get_hash(round(float(q1(13)), 1)) == '4652e04e446dd7e02c704d4189292a1c', 'fitProctorCurve: unexpected value at w=13'\n"
                                               ">>> print('fitProctorCurve ✓ all checks passed')\n"
                                               'fitProctorCurve ✓ all checks passed\n',
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly passes all test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
