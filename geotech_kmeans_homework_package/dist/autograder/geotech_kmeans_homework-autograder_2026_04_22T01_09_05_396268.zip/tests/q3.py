OK_FORMAT = True

test = {   'name': 'q3',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(k)) != '14e736438b115821cbb9b7ac0ba79034'\n"
                                               ">>> assert get_hash(type(clustering_features)) != '14e736438b115821cbb9b7ac0ba79034'\n"
                                               ">>> assert get_hash(type(plotting_features)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function with the plotting cell!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> """ # BEGIN TEST CONFIG\n'
                                               '>>> name: Starting Calcs\n'
                                               '>>> points: 0\n'
                                               '>>> failure_message: Your clusterSoils function is getting some calculations wrong!\n'
                                               '>>> success_message: clusterSoils passes all test cases :D\n'
                                               '>>> """\n'
                                               ">>> _test_features = ['omc_pct', 'mdd_kN_m3']\n"
                                               '>>> _cw, _labs = clusterSoils(_test_features, k=3, seed=0)\n'
                                               ">>> assert isinstance(_cw, np.ndarray), 'clusterSoils: centroids_white should be a numpy array'\n"
                                               ">>> assert isinstance(_labs, np.ndarray), 'clusterSoils: labels should be a numpy array'\n"
                                               ">>> assert _cw.shape == (3, len(_test_features)), f'clusterSoils: centroid shape should be (3, {len(_test_features)}), got {_cw.shape}'\n"
                                               ">>> assert len(_labs) == 36, f'clusterSoils: labels length should be 36, got {len(_labs)}'\n"
                                               ">>> assert set(_labs).issubset({0, 1, 2}), f'clusterSoils: labels should only contain values in {{0, 1, 2}}, got {set(_labs)}'\n"
                                               ">>> assert len(set(_labs)) == 3, 'clusterSoils: all 3 clusters should be non-empty'\n"
                                               ">>> assert get_hash(str(sorted(list(_labs)))) == '10e09e7997ffaa3eb6837e33ff95a9a2', 'clusterSoils: cluster assignments do not match expected output — "
                                               "check your kmeans2 call'\n"
                                               ">>> print('clusterSoils ✓  all checks passed')\n"
                                               'clusterSoils ✓  all checks passed\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
