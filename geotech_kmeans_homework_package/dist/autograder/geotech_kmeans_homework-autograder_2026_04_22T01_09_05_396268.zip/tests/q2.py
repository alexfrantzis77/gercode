OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(ex_id)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> """ # BEGIN TEST CONFIG\n'
                                               '>>> name: Starting Calcs\n'
                                               '>>> points: 0\n'
                                               '>>> failure_message: Your funtion fitProctorCurve is getting some calculations wrong!\n'
                                               '>>> success_message: Function passes all test cases :D\n'
                                               '>>> """\n'
                                               '>>> _w_test = [8, 10, 12, 14, 16, 18]\n'
                                               '>>> _gd_test = [16.5, 17.8, 18.6, 18.9, 18.4, 17.6]\n'
                                               '>>> _poly = fitProctorCurve(_w_test, _gd_test, degree=2)\n'
                                               '>>> q2_omc, q2_mdd = computeOMC_MDD(_poly, min(_w_test), max(_w_test))\n'
                                               ">>> assert abs(q2_omc - 13.8) < 0.5, f'computeOMC_MDD: OMC = {q2_omc:.2f}, expected near 13.8'\n"
                                               ">>> assert abs(q2_mdd - 18.9) < 0.2, f'computeOMC_MDD: MDD = {q2_mdd:.3f}, expected near 18.9'\n"
                                               ">>> print(f'computeOMC_MDD ✓  OMC = {q2_omc:.2f}%,  MDD = {q2_mdd:.3f} kN/m³')\n"
                                               'computeOMC_MDD ✓  OMC = 13.78%,  MDD = 18.826 kN/m³\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
