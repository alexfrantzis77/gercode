OK_FORMAT = True

test = {   'name': 'q4',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> """ # BEGIN TEST CONFIG\n'
                                               '>>> name: Starting Calcs\n'
                                               '>>> points: 0\n'
                                               '>>> failure_message: Make sure to fill out the q4 dictionary!\n'
                                               '>>> success_message: q4 is filled out :D\n'
                                               '>>> """\n'
                                               ">>> assert isinstance(q4, dict), 'q4 should be a dictionary'\n"
                                               ">>> assert set(q4.keys()) == {0, 1, 2}, f'q4 should have keys {{0, 1, 2}}, got {set(q4.keys())}'\n"
                                               '>>> assert all((v != \'...\' for v in q4.values())), "q4 still has unfilled entries — replace \'...\' with \'Sandy\', \'Silty\', or \'Clayey\'"\n'
                                               ">>> print('q4 ✓  dictionary is filled out')\n"
                                               'q4 ✓  dictionary is filled out\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
