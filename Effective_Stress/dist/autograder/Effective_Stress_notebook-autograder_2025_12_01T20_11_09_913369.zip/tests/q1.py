OK_FORMAT = True

test = {   'name': 'q1',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> layers = {'thickness': [0.5, 1.0, 2.0, 1.5, 3.0], 'density': [17.5, 18.0, 19.0, 20.5, 21.0]}\n"
                                               '>>> df = pd.DataFrame(layers)\n'
                                               ">>> assert get_hash(int(10 * np.round(getStress(2, df['thickness'], df['density']), 1))) == 'c3e878e27f52e2a57ace4d9a76fd9acf'\n"
                                               ">>> assert get_hash(int(10 * np.round(getStress(4, df['thickness'], df['density']), 1))) == 'b137fdd1f79d56c7edf3365fea7520f2'\n"
                                               ">>> assert get_hash(int(10 * np.round(getStress(8, df['thickness'], df['density']), 1))) == '228499b55310264a8ea0e27b6e7c6ab6'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly calculates stress for all depth test cases :D'},
                                   {   'code': ">>> layers = {'thickness': [0.5, 1.0, 2.0, 1.5, 3.0], 'density': [17.5, 18.0, 19.0, 20.5, 21.0]}\n"
                                               '>>> df = pd.DataFrame(layers)\n'
                                               ">>> assert get_hash(int(10 * np.round(getStress(5, df['thickness'], df['density']), 1))) == 'ef4e3b775c934dada217712d76f3d51f'\n"
                                               ">>> assert get_hash(int(10 * np.round(getStress(10, df['thickness'], df['density']), 1))) == '228499b55310264a8ea0e27b6e7c6ab6'\n"
                                               ">>> assert get_hash(int(10 * np.round(getStress(20, df['thickness'], df['density']), 1))) == '228499b55310264a8ea0e27b6e7c6ab6'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly calculates stress for all depth test cases :D'},
                                   {   'code': ">>> layers = {'thickness': [0.5, 1.0, 2.0, 1.5, 3.0], 'density': [17.5, 18.0, 19.0, 20.5, 21.0]}\n"
                                               '>>> df = pd.DataFrame(layers)\n'
                                               '>>> depths = np.arange(7)\n'
                                               ">>> print(np.mean(getStress(depths, df['thickness'], df['density'])))\n"
                                               ">>> get_hash(10 * int(np.round(np.mean(getStress(depths, df['thickness'], df['density'])))))\n"
                                               '56.607142857142854\n'
                                               "'a86c450b76fb8c371afead6410d55534'",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> layers = {'thickness': [0.5, 1.0, 2.0, 1.5, 3.0], 'density': [17.5, 18.0, 19.0, 20.5, 21.0]}\n"
                                               '>>> df = pd.DataFrame(layers)\n'
                                               '>>> depths = np.arange(7)\n'
                                               ">>> assert get_hash(int(np.round(np.sum(getStress(depths, df['thickness'], df['density']))))) == 'f8c1f23d6a8d8d7904fc0ea8e066b3bb'\n"
                                               ">>> assert get_hash(int(10 * np.round(np.mean(getStress(depths, df['thickness'], df['density']))))) == 'a86c450b76fb8c371afead6410d55534'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly calculates stress for all depth test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
