OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(int(10 * np.round(getPP(1, water_table_depth=2), 1))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(10 * np.round(getPP(3, water_table_depth=2), 1))) == 'ed3d2c21991e3bef5e069713af9fa6ca'\n"
                                               ">>> assert get_hash(int(10 * np.round(getPP(7, water_table_depth=2), 1))) == '559cb990c9dffd8675f6bc2186971dc2'\n",
                                       'failure_message': 'Your function is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly calculates pore water pressure for all depth test cases :D'},
                                   {   'code': ">>> assert get_hash(int(np.sum(getPP([1, 2, 3, 12], water_table_depth=2)))) == 'a97da629b098b75c294dffdc3e463904'\n"
                                               ">>> assert get_hash(int(np.mean(getPP([1, 2, 3, 12], water_table_depth=2)))) == '4e732ced3463d06de0ca9a15b6153677'\n",
                                       'failure_message': 'Your function is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly calculates pore water pressure for all depth test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
