OK_FORMAT = True

test = {   'name': 'q3',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_xdata()), decimals=0)) == '8ef1bc3e5e466b6c7c905f19ae690f7a'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_ydata()), decimals=0)) == '6febd8047eb9ddc4d9caf141403a586a'\n",
                                       'failure_message': 'Check x and y data of line plot 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[1].get_xdata()), decimals=0)) == 'f9f0ef796b1fc62af121ece66023b801'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[1].get_ydata()), decimals=0)) == '6febd8047eb9ddc4d9caf141403a586a'\n",
                                       'failure_message': 'Check x and y data of line plot 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[2].get_xdata()), decimals=0)) == '3419bd55372df1e7f323ae0c62153ee7'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[2].get_ydata()), decimals=0)) == '6febd8047eb9ddc4d9caf141403a586a'\n",
                                       'failure_message': 'Check x and y data of line plot 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> x_string = ['STRESS', 'KPA']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_xlabel().upper() for word in x_string]), 'Check the x-axis label.'\n"
                                               ">>> y_string = ['DEPTH', 'M']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_ylabel().upper() for word in y_string]), 'Check the y-axis label.'\n",
                                       'failure_message': 'Check figure labels and font sizes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
