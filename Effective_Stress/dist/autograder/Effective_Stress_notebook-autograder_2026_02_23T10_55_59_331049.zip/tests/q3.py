OK_FORMAT = True

test = {   'name': 'q3',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> layers = {'thickness': [2, 5, 7, 10], 'density': [100, 200, 150, 230]}\n"
                                               '>>> df = pd.DataFrame(layers)\n'
                                               ">>> assert get_hash(int(10 * np.round(getEffStress(1, df['thickness'], df['density'], 4), 1))) == 'a9b7ba70783b617e9998dc4dd82eb3c5'\n"
                                               ">>> assert get_hash(int(10 * np.round(getEffStress(7, df['thickness'], df['density'], 4), 1))) == 'f2b1b9275b094c26ff1998a09cd9412d'\n"
                                               ">>> assert get_hash(int(10 * np.round(getEffStress(20, df['thickness'], df['density'], 4), 1))) == '9b3e5c1c0754bc6a379163afabe2af79'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly calculates stress for all depth test cases :D'},
                                   {   'code': ">>> layers = {'thickness': [0.5, 1.0, 2.0, 1.5, 3.0], 'density': [17.5, 18.0, 19.0, 20.5, 21.0]}\n"
                                               '>>> df = pd.DataFrame(layers)\n'
                                               ">>> assert get_hash(int(10 * np.round(getEffStress(1, df['thickness'], df['density'], 2), 1))) == '8f85517967795eeef66c225f7883bdcb'\n"
                                               ">>> assert get_hash(int(10 * np.round(getEffStress(4, df['thickness'], df['density'], 2), 1))) == '5e388103a391daabe3de1d76a6739ccd'\n"
                                               ">>> assert get_hash(int(10 * np.round(getEffStress(7, df['thickness'], df['density'], 2), 1))) == '170c944978496731ba71f34c25826a34'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly calculates stress for all depth test cases :D'},
                                   {   'code': '>>> fig_1 = createFigure()\n'
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_xdata()), decimals=0)) == '774433b9ce2aeed39998fa01a237e669'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_ydata()), decimals=0)) == '6febd8047eb9ddc4d9caf141403a586a'\n"
                                               '<Figure size 600x700 with 1 Axes>',
                                       'failure_message': 'Check x and y data of line plot 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> fig_1 = createFigure()\n'
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[1].get_xdata()), decimals=0)) == 'f9f0ef796b1fc62af121ece66023b801'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[1].get_ydata()), decimals=0)) == '6febd8047eb9ddc4d9caf141403a586a'\n"
                                               '<Figure size 600x700 with 1 Axes>',
                                       'failure_message': 'Check x and y data of line plot 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> fig_1 = createFigure()\n'
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[2].get_xdata()), decimals=0)) == '4e236d0a23708445a975682f99946bd7'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[2].get_ydata()), decimals=0)) == '6febd8047eb9ddc4d9caf141403a586a'\n"
                                               '<Figure size 600x700 with 1 Axes>',
                                       'failure_message': 'Check x and y data of line plot 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> fig_1 = createFigure()\n'
                                               ">>> x_string = ['STRESS', 'KPA']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_xlabel().upper() for word in x_string]), 'Check the x-axis label.'\n"
                                               ">>> y_string = ['DEPTH', 'M']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_ylabel().upper() for word in y_string]), 'Check the y-axis label.'\n"
                                               '<Figure size 600x700 with 1 Axes>',
                                       'failure_message': 'Check figure labels and font sizes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
