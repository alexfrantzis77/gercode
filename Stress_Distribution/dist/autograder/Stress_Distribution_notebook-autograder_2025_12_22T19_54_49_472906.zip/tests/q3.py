OK_FORMAT = True

test = {   'name': 'q3',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> fig_1 = createFigure1()\n'
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_xdata()), decimals=0)) == 'de24d118fbdc1df38f83572b5140dba2'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[0].get_ydata()), decimals=0)) == 'a0daef9095a866b7c3652a1bc0d2fe8d'\n"
                                               '<Figure size 800x500 with 1 Axes>',
                                       'failure_message': 'Check x and y data of line plot 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> fig_1 = createFigure1()\n'
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[1].get_xdata()), decimals=0)) == 'de24d118fbdc1df38f83572b5140dba2'\n"
                                               ">>> assert get_hash(np.round(np.sum(fig_1.axes[0].get_lines()[1].get_ydata()), decimals=0)) == 'e9eda2950317b1a7207dad4d91c03d87'\n"
                                               '<Figure size 800x500 with 1 Axes>',
                                       'failure_message': 'Check x and y data of line plot 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> fig_1 = createFigure1()\n'
                                               ">>> x_string = ['SQUARE', 'WIDTH', 'M']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_xlabel().upper() for word in x_string]), 'Check the x-axis label.'\n"
                                               ">>> y_string = ['STRESS', 'KPA']\n"
                                               ">>> assert all([word in fig_1.axes[0].get_ylabel().upper() for word in y_string]), 'Check the y-axis label.'\n"
                                               '<Figure size 800x500 with 1 Axes>',
                                       'failure_message': 'Check figure labels and font sizes.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
