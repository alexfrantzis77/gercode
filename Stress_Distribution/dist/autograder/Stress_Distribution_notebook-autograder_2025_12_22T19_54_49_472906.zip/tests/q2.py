OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(int(stress_boussinesq(1200, 3, 4, 0, 400, 400))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(stress_boussinesq(1200, 3, 4, 2, 400, 400))) == '44f683a84163b3523afe57c2e008bc8c'\n"
                                               ">>> assert get_hash(int(stress_boussinesq(1200, 3, 4, 5, 400, 400))) == '1f0e3dad99908345f7439f8ffabdffc4'\n"
                                               ">>> assert get_hash(int(stress_boussinesq(1200, 3, 4, 20, 400, 400))) == 'c4ca4238a0b923820dcc509a6f75849b'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all scalar test cases :D'},
                                   {   'code': ">>> assert get_hash(int(stress_boussinesq(20000, 10, 10, 2, 600, 600, 5, 5))) == 'c0c7c76d30bd3dcaefc96f40275bdc0a'\n"
                                               ">>> assert get_hash(int(stress_boussinesq(20000, 10, 10, 4.85, 600, 600, 5, 5))) == 'd9d4f495e875a2e075a1a4a6e1b9770f'\n"
                                               ">>> assert get_hash(int(stress_boussinesq(20000, 10, 10, 20, 600, 600, 5, 5))) == 'c74d97b01eae257e44aa9d5bade97baf'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all scalar test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
