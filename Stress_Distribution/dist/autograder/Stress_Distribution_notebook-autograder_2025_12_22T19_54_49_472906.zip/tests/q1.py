OK_FORMAT = True

test = {   'name': 'q1',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q1)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(np.round(stress_2to1(1200, 3, 4, 0))) == '62dca49f0781bf26b4305bddb0414bea'\n"
                                               ">>> assert get_hash(np.round(stress_2to1(1200, 3, 4, 2))) == '40e5fa722621b4033c15162806b7ea2b'\n"
                                               ">>> assert get_hash(np.round(stress_2to1(1200, 3, 4, 5))) == '8011c1672b96b9446e250a64eb52393f'\n"
                                               ">>> assert get_hash(np.round(stress_2to1(1200, 3, 4, 20))) == 'd1bd83a33f1a841ab7fda32449746cc4'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all scalar test cases :D'},
                                   {   'code': ">>> assert get_hash(np.round(stress_2to1(2000, 10, 10, 0))) == '75cf3ac5e70c76583be3efb5012bd44e'\n"
                                               ">>> assert get_hash(np.round(stress_2to1(2000, 10, 10, 2))) == '038a8a50b863780fe4a43b7a263bb12b'\n"
                                               ">>> assert get_hash(np.round(stress_2to1(2000, 10, 10, 5))) == 'cf5f238fca8b6e155078aa41c175743a'\n"
                                               ">>> assert get_hash(np.round(stress_2to1(2000, 10, 10, 20))) == 'd1bd83a33f1a841ab7fda32449746cc4'\n",
                                       'failure_message': 'Your funtion is getting some calculations wrong!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all scalar test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
