OK_FORMAT = True

test = {   'name': 'q0',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert_condition = get_hash(o) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n"
                                               '>>> if not assert_condition:\n'
                                               "...     raise AssertionError('Try assigning o to 3')\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
