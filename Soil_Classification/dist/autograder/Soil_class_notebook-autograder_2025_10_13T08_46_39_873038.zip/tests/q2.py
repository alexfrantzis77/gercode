OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q2)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(int(coarse(5))) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(int(coarse(40))) == 'c4ca4238a0b923820dcc509a6f75849b'\n"
                                               ">>> assert get_hash(int(coarse(49.9))) == 'c4ca4238a0b923820dcc509a6f75849b'\n",
                                       'failure_message': 'Function is incorrectly classifying some coarse grained test cases!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all coarse grained test cases :D'},
                                   {   'code': ">>> assert get_hash(int(coarse(55))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(coarse(65))) == 'cfcd208495d565ef66e7dff9f98764da'\n"
                                               ">>> assert get_hash(int(coarse(50.1))) == 'cfcd208495d565ef66e7dff9f98764da'\n",
                                       'failure_message': 'Function is incorrectly classifying some fine grained test cases!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0,
                                       'success_message': 'Function correctly classifies all fine grained test cases :D'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
